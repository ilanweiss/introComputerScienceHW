/** A library of operations on two-dimensional matrices. */
public class MatrixOps {
	
	public static void main(String args[]) {
		// Put your testing code here.
		
		// Creates two matrices, for testing
		int[][] a = { 
					    { 7, 2, 1 },
					    { 3, 6, 1 },
					    { 5, 1, 4 },
					 };
		int[][] b = { 
					    { 8, 3, 5 },
					    { 1, 4, 1 },
					    { 1, 3, 4 },
					 }; 
				
		print(a);          System.out.println();
		print(b);          System.out.println();
		print(add(a,b));   System.out.println();
		print(mult(a,b));  System.out.println();
				
		// c = a * (a + b)
		int[][] c = mult(a,add(a,b));
		print(c);          System.out.println();
	}	
	
	/**
	 *  Prints the given matrix.
	 *  
	 *  @param the matrix to be printed.
	 */
	public static void print(int[][] m) {
        // Put your code here.
	}
	

	/**
	 * Adds the two given matrices. Assumes that they have the same dimensions.
	 * 
	 * @param m1 - first summand
	 * @param m2 - second summand
	 * @return the sum of the two matrices
	 */
	public static int[][] add(int[][] m1, int[][] m2) {
		int N = m1.length;    // number of rows
		int M = m1[0].length; // number of columns
		int[][] sum = new int[N][M];
		for (int i = 0; i < N; i++) {
		   for (int j = 0; j < M; j++) {
		      sum[i][j] = m1[i][j] + m2[i][j];
		   }
		}
		return sum;
	}
	
	/**
	 * Checks if the given matrix is symmetric.
	 * 
	 * @param m - the matrix to be tested.
	 * @return true if and only if the matrix is symmetric.
	 */
	public static boolean isSymmetric(int[][] m) {
		// Put your code here.
		return true;  // Replace with the right return statement.
	}
	
	/**
	 * Checks if the two given matrices are equal.
	 * 
	 * @param m1 
	 * @param m2
	 * @return true if and only if m1 equals m2.
	 */
	public static boolean equals(int[][] m1, int[][] m2) {
        // Put your code here.
		return true;  // Replace with the right return statement.
	}
	

	/**
	 * Creates and returns an identity matrix of size N.
	 * 
	 * @param N - the size of the identity matrix.
	 * @return the identity matrix of size N
	 */
	public static int[][] identity(int N) {
		// Put your code here.
		return null;  // Replace with the right return statement.
	}	
		
	/**
	 * Creates and returns the transpose of the given matrix.
	 * 
	 * @param m - the given matrix.
	 * @return a new matrix, which is the transpose of m.
	 */
	public static int[][] transpose(int[][] m) {
		// Put your code here.
	    return null;  // Replace with the right return statement.
	}
	

	/**
	 * Computes and returns the product of the two given matrices.
	 * Assumes that they have compatible dimensions.
	 * 
	 * @param m1
	 * @param m2
	 * @return the product of m1 and m2
	 */
	public static int[][] mult(int[][] m1, int[][] m2) {
	    // Put your code here.
		return null;  // Replace with the right return statement.
	}
	
	// Description of the random function:
	// Given: two positive integers (N and M), and some positive integer (range).
	// The method creates and returns a matrix of N rows and M columns,
	// in which every element is an integer between 0 and range, inclusive.
	// The name of the function is 'random'.
	// You need to complete the method signature and implementation.
	
	// Description of the sub matrix function: 
	// Given: a matrix m and two coordinates specified by the integers 
	// i1, j1, i2, and j2. The method returns a matrix which is the subset
	// m. The top-left element of the subset is m(i1,j1), and the bottom-right
	// element is m(i2,j2). Assume that i2>=i1 and j2>=j1.
	// The name of the function is subMatrix.
	// You need to complete the method signature and implementation.
}