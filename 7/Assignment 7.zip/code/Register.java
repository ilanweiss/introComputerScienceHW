/** Represents a register.
 *  A register is the basic storage unit of the Vic computer. */

public class Register {

    private int value;  // the current value of this register

    /** Constructs a register and sets its value to 0. */
    public Register() {
        // Put your code here
    }

    /** Constructs a register and sets its value to the given value. */
    public Register(int value) {
        // Put your code here
    }

    /** Sets the value of this register to the given value. */
    public void setValue(int value) {
        // Put your code here
    }

    /** Increments the value of this register by 1. */
    public void addOne() {
        // Put your code here
    }

    /** Returns the value of this register, as an int. */
    public int getValue() {
        // Put your code here
    }

    /** Returns the value of this register, as a String. */
    public String toString() {
        // Put your code here
    }
}
